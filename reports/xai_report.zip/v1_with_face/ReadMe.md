- changement dans les couleurs (rouge=beaucoup, bleu=pas beaucoup)
- symmetries selon les valeurs moyennes et non selon les shap
- mise à jour du visuel selon les changements précédents
- ajout de la valeur cible dans le plot "mean auc by dataset"

